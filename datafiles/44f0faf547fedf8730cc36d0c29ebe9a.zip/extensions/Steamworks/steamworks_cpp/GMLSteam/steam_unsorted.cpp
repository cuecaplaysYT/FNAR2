// Steamworks.gml
// author: YellowAfterlife
// license: MIT https://opensource.org/licenses/mit-license.php
//
// This is where pretty much everything happens.
// My sincere apologies if you are using a source code editor that
// does not support collapsing "#pragma region" blocks.


#include "pch.h"
