#include "pch.h"
#include "steam_callbacks.h"
steam_net_callbacks_t steam_net_callbacks;
/*void steam_net_callbacks_t::OnPersonaStateChange(PersonaStateChange_t* e) {
trace("Persona state change %d\n", e->m_ulSteamID);
}*/