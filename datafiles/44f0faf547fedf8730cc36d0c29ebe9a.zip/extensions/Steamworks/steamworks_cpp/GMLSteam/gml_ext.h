#pragma once
#include <vector>
#include <stdint.h>
#include <cstring>
#include <tuple>
using namespace std;
